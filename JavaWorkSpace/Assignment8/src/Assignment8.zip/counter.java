
public class counter {
public long max =0 ;
long max(long l){
	if(l>max)max = l;
	return max;
	
}
}
